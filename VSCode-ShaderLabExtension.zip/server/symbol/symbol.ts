import { SourceRange } from '../parser/token';

export type SymbolKind =
  | 'shader'
  | 'property'
  | 'subShader'
  | 'pass'
  | 'struct'
  | 'field'
  | 'function'
  | 'parameter'
  | 'variable'
  | 'cbuffer'
  | 'macro'
  | 'include'
  | 'typedef';
export interface SymbolLocation {
  uri: string;
  range: SourceRange;
  selectionRange: SourceRange;
}

export interface ShaderSymbol {
  name: string;
  kind: SymbolKind;
  location: SymbolLocation;
  typeName?: string;
  returnType?: string;
  semantic?: string;
  /** 関数パラメータのHLSL修飾子。 */
  qualifier?: 'in' | 'out' | 'inout' | 'uniform';
  parentName?: string;
  children: ShaderSymbol[];
}
